package com.evgen.coupons.dao;																														

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.evgen.coupons.beans.Company;
import com.evgen.coupons.interfaces.dao.ICompanyDao;
import com.evgen.coupons.utils.JdbcUtils;

public class CompanyDao extends JdbcUtils implements ICompanyDao {

	private Connection connection = getConnection();

	@Override
	public void companyCreate(Company company) throws SQLException {
		PreparedStatement statement = null;

		String query = "INSERT INTO COMPANY (COMP_NAME, PASSWORD, EMAIL) " + "VALUES(?, ?, ?)";

		try {
			statement = connection.prepareStatement(query);

			statement.setString(1, company.getCompanyName());
			statement.setString(2, company.getPassword());
			statement.setString(3, company.getEmail());

			statement.executeUpdate();
			System.out.println("Created successfully");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (statement != null) {
				statement.close();
			}
			if (connection != null) {
				connection.close();
				System.out.println("Connection closed");
			}
		}
	}

	@Override
	public List<Company> getAllCompanies() throws SQLException {
		List<Company> companyList = new ArrayList<>();

		String query = "SELECT ID, COMP_NAME, PASSWORD, EMAIL " + "FROM COMPANY";

		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(query);

			ResultSet resultSet = statement.executeQuery(query);

			while (resultSet.next()) {
				Company company = new Company();
				company.setId(resultSet.getLong("ID"));
				company.setCompanyName(resultSet.getString("COMP_NAME"));
				company.setPassword(resultSet.getString("PASSWORD"));
				company.setCompanyName(resultSet.getString("EMAIL"));
				companyList.add(company);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (statement != null) {
				statement.close();
			}
			if (connection != null) {
				connection.close();
				System.out.println("Connection closed");
			}
		}
		return companyList;
	}

	@Override
	public Company companyGetById(Long id) throws SQLException {
		PreparedStatement statement = null;

		String query = "SELECT ID, COMP_NAME, PASSWORD, EMAIL WHERE ID=?";

		Company company = new Company();
		try {
			statement = connection.prepareStatement(query);
			statement.setLong(1, id);

			ResultSet resultSet = statement.executeQuery();

			company.setId(resultSet.getLong("ID"));
			company.setCompanyName(resultSet.getString("CUST_NAME"));
			company.setPassword(resultSet.getString("PASSWORD"));

			statement.executeUpdate();
			System.out.println("Got successfully");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (statement != null) {
				statement.close();
			}
			if (connection != null) {
				connection.close();
				System.out.println("Connection closed");
			}
		}
		return company;
	}

	@Override
	public void companyUpdate(Company company) throws SQLException {
		PreparedStatement statement = null;

		String query = "UPDATE COMPANY SET COMP_NAME=?, PASSWORD=?, EMAIL=?  WHERE ID=0";

		try {
			statement = connection.prepareStatement(query);

			statement.setNString(1, company.getCompanyName());
			statement.setString(2, company.getPassword());
			statement.setString(3, company.getEmail());

			statement.executeUpdate();
			System.out.println("Updated successfully");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (statement != null) {
				statement.close();
			}
			if (connection != null) {
				connection.close();
				System.out.println("Connection closed");
			}
		}
	}

	@Override
	public void companyDelete(Long id) throws SQLException {
		PreparedStatement statement = null;
		Company company = new Company();
		String query = "DELETE FROM COMPANY WHERE ID=?";

		try {
			statement = connection.prepareStatement(query);

			statement.setLong(1, company.getId());

			statement.executeUpdate();
			System.out.println("Deleted successfully");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (statement != null) {
				statement.close();
			}
			if (connection != null) {
				connection.close();
				System.out.println("Connection closed");
			}
		}
	}

}
