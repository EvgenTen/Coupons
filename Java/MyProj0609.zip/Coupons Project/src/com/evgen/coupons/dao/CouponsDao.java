package com.evgen.coupons.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.evgen.coupons.beans.Coupon;
import com.evgen.coupons.enums.ErrorType;
import com.evgen.coupons.interfaces.dao.ICouponsDao;
import com.evgen.coupons.utils.JdbcUtils;

public class CouponsDao extends JdbcUtils implements ICouponsDao {
	
 public String insert = "INSERT INTO COUPON (ID, TITLE, START_DATE, END_DATE, AMOUNT, MESSAGE, PRICE, IMAGE, COMP_ID) "
		+ "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
 private String selectAll = "SELECT ID, TITLE, START_DATE, END_DATE, AMOUNT, MESSAGE, PRICE, IMAGE, COMP_ID "
	+ "FROM COUPON";
 private String getById = "ID, TITLE, START_DATE, END_DATE, AMOUNT, MESSAGE, PRICE, IMAGE, COMP_ID WHERE ID=?";
 private String update = "UPDATE COUPON SET TITLE, START_DATE, END_DATE, AMOUNT, MESSAGE, PRICE, IMAGE, COMP_ID WHERE ID=0";
 private String delete = "DELETE FROM COUPON WHERE ID=?";
 
	private Connection connection = getConnection();

	@Override
	public void couponCreate(Coupon coupon) throws SQLException {
		PreparedStatement statement = null;

		String query = insert;

		try {
			statement = connection.prepareStatement(query);

			statement.setLong(1, coupon.getId());
			statement.setString(2, coupon.getTitle());
			statement.setString(3, coupon.getStartDate());
			statement.setString(4, coupon.getEndDate());
			statement.setInt(5, coupon.getAmount());
			statement.setString(6, coupon.getMessage());
			statement.setFloat(7, coupon.getPrice());
			statement.setString(8, coupon.getImage());
			statement.setLong(9, coupon.getCompanyId());

			statement.executeUpdate();
			System.out.println("Created successfully");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (statement != null) {
				statement.close();
			}
			if (connection != null) {
				connection.close();
				System.out.println("Connection closed");
			}
		}
	}

	@Override
	public List<Coupon> getAllCoupons() throws SQLException {
		List<Coupon> couponList = new ArrayList<>();

		String query = selectAll;

		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(query);

			ResultSet resultSet = statement.executeQuery(query);

			while (resultSet.next()) {
				Coupon coupon = new Coupon();
				coupon.setId(resultSet.getLong("ID"));
				coupon.setTitle(resultSet.getString("TITLE"));
				coupon.setStartDate(resultSet.getString("START_DATE"));
				coupon.setEndDate(resultSet.getString("END_DATE"));
				coupon.setAmount(resultSet.getInt("AMOUNT"));
				coupon.setMessage(resultSet.getString("MESSAGE"));
				coupon.setImage(resultSet.getString("IMAGE"));
				coupon.setId(resultSet.getLong("COMP_ID"));

				couponList.add(coupon);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (statement != null) {
				statement.close();
			}
			if (connection != null) {
				connection.close();
				System.out.println("Connection closed");
			}
		}
		return couponList;
	}

	@Override
	public Coupon couponGetById(Long id) throws SQLException {
		PreparedStatement statement = null;

		String query = getById;

		Coupon coupon = new Coupon();
		try {
			statement = connection.prepareStatement(query);
			statement.setLong(1, id);

			ResultSet resultSet = statement.executeQuery();

			coupon.setId(resultSet.getLong("ID"));
			coupon.setTitle(resultSet.getString("TITLE"));
			coupon.setStartDate(resultSet.getString("START_DATE"));
			coupon.setEndDate(resultSet.getString("END_DATE"));
			coupon.setAmount(resultSet.getInt("AMOUNT"));
			coupon.setMessage(resultSet.getString("MESSAGE"));
			coupon.setImage(resultSet.getString("IMAGE"));
			coupon.setId(resultSet.getLong("COMP_ID"));

			statement.executeUpdate();
			System.out.println("Got successfully");
		} catch (SQLException e) {
			ErrorType.COUPON_CREATION_ERROR.name();
		} finally {
			if (statement != null) {
				statement.close();
			}
			if (connection != null) {
				connection.close();
				System.out.println("Connection closed");
			}
		}
		return coupon;
	}

	@Override
	public void couponUpdate(Coupon coupon) throws SQLException {
		PreparedStatement statement = null;

		String query = update;

		try {
			statement = connection.prepareStatement(query);

			statement.setString(1, coupon.getTitle());
			statement.setString(2, coupon.getStartDate());
			statement.setString(3, coupon.getEndDate());
			statement.setInt   (4, coupon.getAmount());
			statement.setString(5, coupon.getMessage());
			statement.setFloat (6, coupon.getPrice());
			statement.setString(7, coupon.getImage());
			statement.setLong  (8, coupon.getCompanyId());

			statement.executeUpdate();
			System.out.println("Updated successfully");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (statement != null) {
				statement.close();
			}
			if (connection != null) {
				connection.close();
				System.out.println("Connection closed");
			}
		}
	}

	@Override
	public void couponDeleteById(Long id) throws SQLException {
		PreparedStatement statement = null;
		Coupon coupon = new Coupon();
		String query = delete;

		try {
			statement = connection.prepareStatement(query);

			statement.setLong(1, coupon.getId());

			statement.executeUpdate();
			System.out.println("Deleted successfully");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (statement != null) {
				statement.close();
			}
			if (connection != null) {
				connection.close();
				System.out.println("Connection closed");
			}
		}
	}
}
