package com.evgen.coupons.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.evgen.coupons.beans.Customer;
import com.evgen.coupons.interfaces.dao.iCustomerDao;
import com.evgen.coupons.utils.JdbcUtils;

public class CustomerDao extends JdbcUtils implements iCustomerDao {

	private Connection connection = getConnection();

	@Override
	public void customerCreate(Customer customer) throws SQLException {
		PreparedStatement statement = null;

		String query = "INSERT INTO CUSTOMER (ID, CUST_NAME, PASSWORD) " + "VALUES(?, ?, ?)";

		try {
			statement = connection.prepareStatement(query);

			statement.setLong(1, customer.getId());
			statement.setString(2, customer.getCustomerName());
			statement.setString(3, customer.getPassword());

			statement.executeUpdate();
			System.out.println("Created successfully");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (statement != null) {
				statement.close();
			}
			if (connection != null) {
				connection.close();
				System.out.println("Connection closed");
			}
		}
	}

	@Override
	public List<Customer> getAllCustomers() throws SQLException {
		List<Customer> customerList = new ArrayList<>();

		String query = "SELECT ID, CUST_NAME, PASSWORD " + "FROM CUSTOMER";

		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(query);

			ResultSet resultSet = statement.executeQuery(query);

			while (resultSet.next()) {
				Customer customer = new Customer();
				customer.setId(resultSet.getLong("ID"));
				customer.setCustomerName(resultSet.getString("CUST_NAME"));
				customer.setPassword(resultSet.getString("PASSWORD"));

				customerList.add(customer);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (statement != null) {
				statement.close();
			}
			if (connection != null) {
				connection.close();
				System.out.println("Connection closed");
			}
		}
		return customerList;
	}

	@Override
	public Customer getById(Long id) throws SQLException {
		PreparedStatement statement = null;

		String query = "SELECT ID, CUST_NAME, PASSWORD WHERE ID=?";

		Customer customer = new Customer();
		try {
			statement = connection.prepareStatement(query);
			statement.setLong(1, id);

			ResultSet resultSet = statement.executeQuery();

			customer.setId(resultSet.getLong("ID"));
			customer.setCustomerName(resultSet.getString("CUST_NAME"));
			customer.setPassword(resultSet.getString("PASSWORD"));

			statement.executeUpdate();
			System.out.println("Got successfully");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (statement != null) {
				statement.close();
			}
			if (connection != null) {
				connection.close();
				System.out.println("Connection closed");
			}
		}
		return customer;
	}

	@Override
	public void customerUpdate(Customer customer) throws SQLException {
		PreparedStatement statement = null;

		String query = "UPDATE CUSTOMER SET CUST_NAME=?, PASSWORD=? WHERE ID=?";

		try {
			statement = connection.prepareStatement(query);
			
			statement.setString(1, customer.getCustomerName());
			statement.setString(2, customer.getPassword());
			statement.setLong(3, customer.getId());

			statement.executeUpdate();
			System.out.println("Updated successfully");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (statement != null) {
				statement.close();
			}
			if (connection != null) {
				connection.close();
				System.out.println("Connection closed");
			}
		}
	}

	@Override
	public void customerDeleteById(Long id) throws SQLException {
		PreparedStatement statement = null;
		System.out.println(id + "  1");
		//Customer customer = new Customer();
		String query = "DELETE FROM CUSTOMER WHERE ID=?";
		
		try {
			statement = connection.prepareStatement(query);
		//	System.out.println(customer.getId());
			statement.setLong(1, id);

			statement.executeUpdate();
			System.out.println("Deleted successfully");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (statement != null) {
				statement.close();
			}
			if (connection != null) {
				connection.close();
				System.out.println("Connection closed");
			}
		}
	}

}
