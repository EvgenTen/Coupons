package com.evgen.coupons.logic;

public class CouponsController {

}
