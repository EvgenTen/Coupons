package com.evgen.coupons.enums;


public enum ErrorType {
	COUPON_CREATION_ERROR ("Can`t create coupon"),
//	COUPON_DELETE_ERROR,
//	COUPON_UPDATE_ERROR,
//	COUPON_RETREIVE_ERROR,
//	
//	USER_ERROR,
//	GENERAL_ERROR,
//	
//	COMPANY_CREATION_ERROR,
//	COMPANY_DELETE_ERROR,
//	COMPANY_UPDATE_ERROR,
//	COMPANY_RETREIVE_ERROR,
//	
//	CUSTOMER_CREATION_ERROR,
//	CUSTOMER_DELETE_ERROR,
//	CUSTOMER_UPDATE_ERROR,
//	CUSTOMER_RETREIVE_ERROR,
//	
//	DATABASE_CONNECTION_ERROR,
//	DATABASE_CONNECTION_CLOSING_ERROR
	;

	private String name;

	private ErrorType(String name) {
		this.setName(name);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
