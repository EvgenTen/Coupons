package com.evgen.coupons.enums;

public enum CouponType {

	VIP,
	NOT_VIP,
}
