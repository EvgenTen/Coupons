package com.evgen.coupons.interfaces.dao;

import java.sql.SQLException;
import java.util.List;
import com.evgen.coupons.beans.Company;

public interface ICompanyDao {
	 //create
	 void companyCreate(Company company) throws SQLException;
	 //delete
	 void companyDelete(Long id) throws SQLException;
	 //update
	 void companyUpdate(Company company) throws SQLException;

	//collection read
	 List<Company> getAllCompanies() throws SQLException;
	 
	 Company companyGetById(Long id) throws SQLException;

} 