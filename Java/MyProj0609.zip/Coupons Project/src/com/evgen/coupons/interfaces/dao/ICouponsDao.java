package com.evgen.coupons.interfaces.dao;

import java.sql.SQLException;
import java.util.List;
import com.evgen.coupons.beans.Coupon;

public interface ICouponsDao {

	 //create
	 void couponCreate(Coupon Coupon) throws SQLException;
	 //delete
	 void couponDeleteById(Long id) throws SQLException;
	 //update
	 void couponUpdate(Coupon coupon) throws SQLException;

	//collection read
	 List<Coupon> getAllCoupons()throws SQLException;
	 
	 Coupon couponGetById(Long id)throws SQLException;
	 
	
}
