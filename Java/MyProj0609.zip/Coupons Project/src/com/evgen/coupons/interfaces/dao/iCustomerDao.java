package com.evgen.coupons.interfaces.dao;

import java.sql.SQLException;
import java.util.List;
import com.evgen.coupons.beans.Customer;

public interface iCustomerDao {

	 //create
	 void customerCreate(Customer customer) throws SQLException;
	 //delete
	 abstract void customerDeleteById(Long id) throws SQLException;
	 //update
	 void customerUpdate(Customer customer) throws SQLException;

	//collection read
	 List<Customer> getAllCustomers() throws SQLException;
	 
	Customer getById(Long id) throws SQLException;
	
	//void customerDelete(Customer customer) throws SQLException;
	
	
	 
}
