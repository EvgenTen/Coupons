
package com.evgen.coupons.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class JdbcUtils {

    private static final String DB_DRIVER = "com.mysql.jdbc.Driver";
    private static final String DB_URL = "jdbc:mysql://127.0.0.1:3306/CouponsProjectDB?useSSL=false";
    private static final String DB_USERNAME = "root";
    private static final String DB_PASSWORD = "12345";

    public Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName(DB_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
            System.out.println("Connection OK");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            System.out.println("Connection ERROR");
        }
        return connection;
    }

}








//package com.evgen.coupons.utils;
//
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.sql.Connection;
//
//public class JdbcUtils {
//
//	static {
//		try {
//			Class.forName("com.mysql.jdbc.Driver");
//		} catch (ClassNotFoundException e) {
//			
//			e.printStackTrace();
//		}
//	}
//
//	public static Connection getConnection() throws SQLException {
//		Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/CouponsProjectDB?useSSL=false",
//				"root", "12345");
//
//		return connection;
//	}
//
//	public static void closeResources(Connection connection, PreparedStatement statement) {
//		try {
//			if (connection != null) {
//				connection.close();
//				System.out.println("Connection closed");
//			}
//		} catch (SQLException e) {
//		
//			e.printStackTrace();
//			System.out.println("Connection close failed");
//			// Write to log that we have a resource leak
//		}
//
//		try {
//			if (statement != null) {
//				statement.close();
//			}
//		} catch (SQLException e) {
//			// Write to log that we have a resource leak
//			e.printStackTrace();
//		}
//	}
//
//	public static void closeResources(Connection connection, PreparedStatement statement, ResultSet resultSet) {
//		closeResources(connection, statement);
//		try {
//			if (resultSet != null) {
//				resultSet.close();
//			}
//		} catch (SQLException e) {
//			// Write to log that we have a resource leak
//			e.printStackTrace();
//		}
//
//	}
//
//}
