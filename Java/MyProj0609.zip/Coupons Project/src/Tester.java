
import com.evgen.coupons.dao.CouponsDao;
import com.evgen.coupons.utils.JdbcUtils;

public class Tester {
	
	
	public static void main(String[] args) {
		
		JdbcUtils util = new JdbcUtils();
	
	
			util.getConnection();
			if(util.getConnection() !=null) {
			System.out.println("Connection OK");
			}else
			System.out.println("Connection ERROR");
		}
	}


