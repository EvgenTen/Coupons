import java.sql.SQLException;
import java.util.List;

import com.evgen.coupons.beans.Coupon;
import com.evgen.coupons.beans.Customer;
import com.evgen.coupons.dao.CompanyDao;
import com.evgen.coupons.dao.CouponsDao;
import com.evgen.coupons.dao.CustomerDao;
import com.evgen.coupons.utils.JdbcUtils;

public class Domain {

	

	    public static void main(String[] args) {
	    	CustomerDao customer = new CustomerDao();
	    	CouponsDao couponsDao = new CouponsDao();
	    	CompanyDao companyDao = new CompanyDao();
	//        AddressService addressService = new AddressService();
//	        EmployeeService employeeService = new EmployeeService();
//	        ProjectService projectService = new ProjectService();
//	        EmplProjService emplProjService = new EmplProjService();
//


	    	
//	    	Customer cust = new Customer();
//	        //employee.setId(1L);
//	    	cust.setCustomerName("Udo");
//	    	cust.setPassword("123123");
//
	    	Coupon coupon = new Coupon();
	    	
			coupon.setTitle("Coupon from Shmulik");
			coupon.setStartDate("15.01.2018");
			coupon.setEndDate("25.02.2018");
			coupon.setAmount(10);
			coupon.setMessage("yes");
			coupon.setImage("IMAGE");
			coupon.setId();
			
//	        Calendar calendar = Calendar.getInstance();
//	        calendar.set(1939, Calendar.MAY, 1);
//
//	        employee.setBirthday(new java.sql.Date(calendar.getTime().getTime()));
//	        employee.setAddressId(address.getId());
//
//	        Project project = new Project();
//	        project.setId(1L);
//	        project.setTitle("Gotham City Police Department Commissioner");
//
//	        EmplProj emplProj = new EmplProj();
//	        emplProj.setEmployeeId(employee.getId());
//	        emplProj.setProjectId(project.getId());

	        try {
	//            customer.customerCreate(cust);
	       	couponsDao.couponCreate(coupon);
	     //   	customer.getAllCustomers();
//	            employeeService.add(employee);
//	            projectService.add(project);
//	            emplProjService.add(emplProj);

//	            List<Address> addressList = addressService.getAll();
	            List<Customer> customerList = customer.getAllCustomers();
	            for (Customer c : customerList) {
	                System.out.println(c);
	            }

	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	}


