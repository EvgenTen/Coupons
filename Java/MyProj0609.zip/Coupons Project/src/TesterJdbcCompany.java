import java.sql.SQLException;

import com.evgen.coupons.beans.Company;
import com.evgen.coupons.beans.Customer;
import com.evgen.coupons.dao.CompanyDao;
import com.evgen.coupons.dao.CustomerDao;

public class TesterJdbcCompany {

	public static void main(String[] args) {
	
//		Company company = new Company ("nazi ko", "111111", "nazbol@gmail.com");
//		CompanyDao dao = new CompanyDao();
//		try {
//			dao.companyCreate(company);
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//		Customer customer = new Customer("john", "123");
//		CustomerDao cusDao = new CustomerDao();
//		try {
//			cusDao.customerCreate(customer);
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		//Customer customer = new Customer();
		CustomerDao cusDao = new CustomerDao();
		try {
			cusDao.customerDeleteById((long) 15);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
//		JdbcUtils util = new JdbcUtils();
//		
//		try {
//			util.getConnection();
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}

	}

}
